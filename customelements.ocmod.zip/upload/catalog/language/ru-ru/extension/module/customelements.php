<?php
    $_['heading_title'] = 'Пример модуля';
    $_['text_customelements']  = 'Категории';
    $_['text_error']    = 'Модуль выключен';
?>