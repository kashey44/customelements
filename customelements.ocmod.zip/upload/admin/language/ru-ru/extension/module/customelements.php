<?php
    $_['heading_title']  = 'Элементы на главной';
    $_['text_extension'] = 'Расширения';
    $_['text_success']   = 'Настройки успешно изменены!';
    $_['text_edit']      = 'Настройки модуля';
    $_['entry_status']   = 'Статус';
    $_['text_enabled']   = 'Включено';
    $_['entry_title']  = 'Текст ссылки';
    $_['entry_link']  = 'URL';
    $_['entry_image']  = 'Изображение';
    $_['entry_sort_order']  = 'Порядок сортировки';
    



?>